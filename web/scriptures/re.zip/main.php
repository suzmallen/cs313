<?php
require "connect.php";
$db = get_db();

?>

<html>
<head>
</head>
<body>
<form action="proccess.php" method="post">
    <h1>Enter scriptures:</h1><br> 
    <label><b>Book</b></label>
    <input type="text" placeholder="Enter book" name="book" required><br>

    <label><b>Chapter</b></label>
    <input type="text" placeholder="Enter chapter" name="chapter" required><br>

    <label><b>Verse</b></label>
    <input type="text" placeholder="Enter Name" name="verse" required><br>
    
    Content:<br>
    <textarea type="text" placeholder="Enter text" name="content" rows="10" cols="50" required>
    	
    </textarea><br>
       
     <?php   

	foreach ($db->query('SELECT * FROM topic') as $row)
    {
    echo '<input type="checkbox" name="topic[]" value="'.$row['id'].'">'.$row['name'].'</input>'."<br>";
    }
    ?>


    <button class="button1" type="submit">Add to database</button>
  </div>
</form>

</body>
</html>